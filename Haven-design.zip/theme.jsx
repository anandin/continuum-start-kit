// theme.jsx — three aesthetic directions for Haven
// Each theme defines color tokens, type stack, and motif (subtle bg, accents).

const THEMES = {
  sanctuary: {
    name: 'Sanctuary',
    sub: 'Calm clinical · sage & cream',
    bg: '#F2EEE5',
    bgSoft: '#EAE4D6',
    paper: '#FFFFFF',
    paperWarm: '#FBF8F1',
    ink: '#1F2A24',
    inkSoft: '#5C6962',
    inkFaint: '#8A958E',
    primary: '#4A6B5C',
    primaryDeep: '#2F4A3E',
    primarySoft: '#DDE5DF',
    accent: '#C8956D',
    accentSoft: '#F1E4D2',
    line: '#D9D2C2',
    lineSoft: '#E5DECE',
    night: '#1A2520',         // for 2am pause
    nightInk: '#E8DCC0',
    nightAccent: '#C8956D',
    danger: '#A8553B',
    serif: '"Newsreader", "Source Serif 4", Georgia, serif',
    sans: '"Geist", "Inter", system-ui, -apple-system, sans-serif',
    mono: '"Geist Mono", ui-monospace, monospace',
    headlineWeight: 400,
    radius: 14,
    radiusLg: 22,
  },
  hearth: {
    name: 'Hearth',
    sub: 'Warm human · terracotta & sand',
    bg: '#F0E5D2',
    bgSoft: '#E8DAC0',
    paper: '#FBF6EC',
    paperWarm: '#F6EBD6',
    ink: '#2A1F14',
    inkSoft: '#6E5840',
    inkFaint: '#A08C70',
    primary: '#B85C2F',
    primaryDeep: '#7E3C1B',
    primarySoft: '#F0D9C2',
    accent: '#4A5D3F',
    accentSoft: '#D8DDC9',
    line: '#D5C5A4',
    lineSoft: '#E5D8B8',
    night: '#241710',
    nightInk: '#F0DCC9',
    nightAccent: '#E69A6A',
    danger: '#B53A2A',
    serif: '"Lora", "Cormorant Garamond", Georgia, serif',
    sans: '"DM Sans", "Inter", system-ui, sans-serif',
    mono: '"DM Mono", ui-monospace, monospace',
    headlineWeight: 500,
    radius: 18,
    radiusLg: 28,
  },
  quiet: {
    name: 'Quiet',
    sub: 'Editorial luxury · ivory & ink',
    bg: '#F4F2EC',
    bgSoft: '#ECE9DF',
    paper: '#FCFAF4',
    paperWarm: '#F8F5EB',
    ink: '#15140F',
    inkSoft: '#5A574E',
    inkFaint: '#8F8B7E',
    primary: '#2A2722',
    primaryDeep: '#0E0D0A',
    primarySoft: '#E5DFD0',
    accent: '#8B6B3D',
    accentSoft: '#EFE6D0',
    line: '#D8D2C2',
    lineSoft: '#E8E2D0',
    night: '#0F0E0B',
    nightInk: '#E5DFCD',
    nightAccent: '#C9A872',
    danger: '#7C2B22',
    serif: '"Instrument Serif", "Playfair Display", Georgia, serif',
    sans: '"Geist", "Inter", system-ui, sans-serif',
    mono: '"Geist Mono", ui-monospace, monospace',
    headlineWeight: 400,
    radius: 8,
    radiusLg: 14,
  },
};

const TONES = {
  warm: {
    label: 'Warm friend',
    greeting: 'Hey, you. How are you arriving tonight?',
    pause: 'I see you. Let\'s slow this down together.',
  },
  steady: {
    label: 'Steady clinician',
    greeting: 'Welcome back. What feels most present right now?',
    pause: 'You\'ve landed somewhere hard. We can be here a moment.',
  },
  curious: {
    label: 'Curious coach',
    greeting: 'Hi — what\'s asking for your attention today?',
    pause: 'Something woke you. What was it carrying?',
  },
  reflective: {
    label: 'Reflective companion',
    greeting: 'Soft hello.\nWhat are you noticing?',
    pause: 'Quiet hour.\nYou\'re here. That counts.',
  },
};

const ThemeCtx = React.createContext({ t: THEMES.sanctuary, tone: TONES.warm, key: 'sanctuary' });
const useTheme = () => React.useContext(ThemeCtx);

window.THEMES = THEMES;
window.TONES = TONES;
window.ThemeCtx = ThemeCtx;
window.useTheme = useTheme;
