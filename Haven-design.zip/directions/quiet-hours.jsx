// QUIET HOURS — Night + Morning
// Same warm, lamp-lit direction. Two palettes that share copy and layout.
// Night: dimmed lamp, candlelight gold, blush. For 2am.
// Morning: parchment cream, deep gold, terracotta. For "before the meeting at 10."

// Palette — researched alternative to the AI-tool gold-on-dark cliche.
// Anchor: dusty clay rose (heart, skin, blood-warmth — human, not metal).
// Steadier: muted sage (the co-regulating-breath color).
// Night: deep indigo-plum, like a real night sky.
// Morning: oatmeal bone with a sage undertone, not cream-yellow.

const QH_NIGHT = {
  name: 'night',
  bg: '#15131D',
  bgSoft: '#1B1828',
  surface: '#1F1C2E',
  surfaceHi: '#272338',
  text: '#EFE6DC',
  textSoft: '#D9CFC4',
  muted: '#9089A2',
  dim: '#5A536A',
  accent: '#E8A89C',          // dusty clay rose — primary
  accentSoft: '#F0BFB6',
  accentInk: '#15131D',
  blush: '#E8A89C',
  sage: '#9FBBA5',            // muted sage — secondary
  border: 'rgba(232,168,156,0.20)',
  borderSoft: 'rgba(239,230,220,0.08)',
  pageGrad: 'linear-gradient(180deg, #1B1828 0%, #15131D 70%)',
  pageGradSoft: 'linear-gradient(180deg, #1B1828 0%, #15131D 50%)',
  chatGrad: 'radial-gradient(ellipse at 50% 22%, rgba(232,168,156,0.18) 0%, transparent 60%), linear-gradient(180deg, #1B1828, #15131D)',
  glowRGBA: 'rgba(232,168,156,0.22)',
  glowRGBASoft: 'rgba(232,168,156,0.10)',
  cardSoftGrad: 'linear-gradient(180deg, rgba(232,168,156,0.13) 0%, rgba(232,168,156,0.04) 100%)',
  cardGoldGrad: 'linear-gradient(180deg, rgba(232,168,156,0.13), rgba(232,168,156,0.03))',
  thinDivider: 'linear-gradient(90deg, transparent, rgba(232,168,156,0.50), transparent)',
  pillActiveBg: 'rgba(232,168,156,0.10)',
  iconChipBg: 'rgba(232,168,156,0.10)',
  iconChipBgHi: 'rgba(232,168,156,0.20)',
  btnShadow: '0 10px 26px rgba(232,168,156,0.22)',
  composerShadow: '0 8px 24px rgba(0,0,0,0.4)',
  statusDark: true,
  statusPillBg: '#272338',
  // copy
  partOfDay: 'evening',
  greeting: 'how are you, really?',
  greetingHand: 'hey Sam,',
  noteTime: '6:42 PM',
  chatTitle: 'Quiet hours with Maya',
  chatStatus: 'Maya signed off at 9 \u00B7 I\u2019m here with you',
  windDownLabel: 'A SOFT WIND-DOWN \u00B7 9 MIN',
  journalLabel: 'tonight\u2019s prompt',
  homePromptLabel: 'A LITTLE NOTE FROM MAYA',
};

const QH_MORNING = {
  name: 'morning',
  bg: '#EFE9DC',              // oatmeal bone, not cream-yellow
  bgSoft: '#F4EFE3',
  surface: '#F9F5EB',
  surfaceHi: '#FFFFFF',
  text: '#1F1B2A',            // matches night bg — they rhyme
  textSoft: '#3D3849',
  muted: '#7A7286',
  dim: '#A8A0B1',
  accent: '#C8786B',          // richer clay/coral by daylight
  accentSoft: '#DC9587',
  accentInk: '#FFFFFF',
  blush: '#C8786B',
  sage: '#6F8E73',            // forest sage
  border: 'rgba(200,120,107,0.26)',
  borderSoft: 'rgba(31,27,42,0.10)',
  pageGrad: 'linear-gradient(180deg, #F4EFE3 0%, #EFE9DC 60%, #E8E2D2 100%)',
  pageGradSoft: 'linear-gradient(180deg, #F4EFE3 0%, #EFE9DC 60%)',
  chatGrad: 'radial-gradient(ellipse at 50% 22%, rgba(200,120,107,0.22) 0%, transparent 55%), linear-gradient(180deg, #F4EFE3 0%, #E8E2D2 100%)',
  glowRGBA: 'rgba(200,120,107,0.28)',
  glowRGBASoft: 'rgba(200,120,107,0.14)',
  cardSoftGrad: 'linear-gradient(180deg, rgba(200,120,107,0.13) 0%, rgba(200,120,107,0.03) 100%)',
  cardGoldGrad: 'linear-gradient(180deg, rgba(200,120,107,0.16), rgba(200,120,107,0.04))',
  thinDivider: 'linear-gradient(90deg, transparent, rgba(200,120,107,0.55), transparent)',
  pillActiveBg: 'rgba(200,120,107,0.10)',
  iconChipBg: 'rgba(200,120,107,0.10)',
  iconChipBgHi: 'rgba(200,120,107,0.18)',
  btnShadow: '0 10px 26px rgba(200,120,107,0.22)',
  composerShadow: '0 10px 24px rgba(31,27,42,0.10)',
  statusDark: false,
  statusPillBg: '#F9F5EB',
  partOfDay: 'morning',
  greeting: 'how are you, really?',
  greetingHand: 'good morning, Sam',
  noteTime: '6:42 AM',
  chatTitle: 'Morning with Maya',
  chatStatus: 'Maya\u2019s with clients \u00B7 I\u2019m here while you wake up',
  windDownLabel: 'A GROUNDING START \u00B7 9 MIN',
  journalLabel: 'this morning\u2019s prompt',
  homePromptLabel: 'A LITTLE NOTE FROM MAYA',
};

function getQH(mode) {
  return mode === 'morning' ? QH_MORNING : QH_NIGHT;
}

function makeTheme(QH) {
  return {
    bg: QH.bg, text: QH.text, muted: QH.muted, accent: QH.accent,
    border: QH.border, font: '"Geist", -apple-system, system-ui, sans-serif',
    tabBg: QH.name === 'night' ? 'rgba(20,16,13,0.85)' : 'rgba(255,250,240,0.85)',
    tabBorder: `1px solid ${QH.borderSoft}`, tabActive: QH.accent,
  };
}

const FONT = '"Geist", -apple-system, system-ui, sans-serif';
const SERIF = '"Instrument Serif", Georgia, serif';
const HAND = '"Caveat", cursive';

// A11y helpers — used by every component below.
//  fH: handwriting font (swap to Geist semibold in reading mode)
//  fS: serif font (swap to Geist in reading mode — kills italic body too)
//  s : font size (clamp to >=12 in reading mode for label-tier text)
const fH = (a) => (a ? FONT : HAND);
const fS = (a) => (a ? FONT : SERIF);
const s  = (a, n) => (a && n < 12 ? 12 : n);
const it = (a) => (a ? 'normal' : 'italic');
const ls = (a, n) => (a ? Math.min(n, 0.6) : n); // tighten loose tracking on small caps in reading mode
const wt = (a, n) => (a ? Math.max(n, 500) : n); // beef weight on body
// Lift muted/dim contrast in reading mode
function liftContrast(QH, a) {
  if (!a) return QH;
  return QH.name === 'night'
    ? { ...QH, muted: '#B5AECD', dim: '#8A82A0' }
    : { ...QH, muted: '#5C5466', dim: '#7E7689' };
}

function LampGlow({ top = 60, x = '50%', size = 380, color }) {
  return (
    <div style={{
      position: 'absolute', top, left: x, transform: 'translateX(-50%)',
      width: size, height: size, borderRadius: '50%',
      background: `radial-gradient(circle, ${color} 0%, transparent 65%)`,
      pointerEvents: 'none', zIndex: 0,
    }}/>
  );
}

// ─────────────────────────────────────────────────
// 1. Welcome
// ─────────────────────────────────────────────────
function QHWelcome() {
  const a11y = useA11y();
  const QH = liftContrast(getQH(useMode()), a11y);
  const HAND = fH(a11y), SERIF = fS(a11y);
  return (
    <Phone theme={makeTheme(QH)} statusDark={QH.statusDark}>
      <div style={{ paddingTop: 56, height: '100%', position: 'relative', overflow: 'hidden',
        background: QH.pageGrad }}>
        <LampGlow top={120} size={420} color={QH.glowRGBA}/>

        <div style={{ position: 'relative', padding: '40px 30px 0', zIndex: 1, height: '100%', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M3 12a9 9 0 0118 0c0 4-3 8-9 8s-9-4-9-8z" stroke={QH.accent} strokeWidth="1.4"/>
              <circle cx="12" cy="12" r="2" fill={QH.accent}/>
            </svg>
            <span style={{ fontFamily: FONT, fontSize: 12, letterSpacing: 2, color: QH.muted, textTransform: 'uppercase' }}>
              Haven
            </span>
          </div>

          <div style={{ marginTop: 80 }}>
            <div style={{ fontFamily: HAND, fontSize: 22, color: QH.blush, marginBottom: 14, letterSpacing: 0.3 }}>
              hi, you.
            </div>
            <div style={{ fontFamily: SERIF, fontSize: 44, lineHeight: 1.02, color: QH.text, letterSpacing: -0.8 }}>
              We&rsquo;re glad you&rsquo;re here.
            </div>
            <div style={{ fontFamily: SERIF, fontSize: 19, lineHeight: 1.5, color: QH.textSoft, marginTop: 22, fontStyle: 'italic', opacity: 0.92 }}>
              Haven is for the slow nights, the hard mornings, and the small in-between moments &mdash; with a real therapist behind every word.
            </div>
          </div>

          <div style={{ marginTop: 36, display: 'flex', flexDirection: 'column', gap: 18 }}>
            {[
              { i: 'moon', t: 'Always here', d: '2am, Tuesday lunch, before a meeting.' },
              { i: 'heart', t: 'Trained by Maya', d: 'A licensed therapist who reviews everything.' },
              { i: 'leaf', t: 'Yours, privately', d: 'Nothing leaves this app without you saying so.' },
            ].map((row) => (
              <div key={row.i} style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
                <div style={{ width: 36, height: 36, borderRadius: 18,
                  background: QH.iconChipBg, border: `1px solid ${QH.border}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', color: QH.accent, flexShrink: 0 }}>
                  <Icon name={row.i} size={16}/>
                </div>
                <div>
                  <div style={{ fontFamily: FONT, fontSize: 14, color: QH.text, fontWeight: 500 }}>{row.t}</div>
                  <div style={{ fontFamily: FONT, fontSize: 12, color: QH.muted, marginTop: 2, lineHeight: 1.4 }}>{row.d}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 'auto', paddingBottom: 30 }}>
            <button style={{
              width: '100%', height: 54, borderRadius: 27, border: 'none',
              background: QH.accent, color: QH.accentInk,
              fontFamily: FONT, fontSize: 15, fontWeight: 600, letterSpacing: 0.2,
              boxShadow: QH.btnShadow, cursor: 'pointer',
            }}>
              Take the first step
            </button>
            <div style={{ textAlign: 'center', marginTop: 14, fontFamily: FONT, fontSize: 12, color: QH.muted }}>
              No rush. <span style={{ color: QH.textSoft }}>You can move at your pace.</span>
            </div>
          </div>
        </div>
      </div>
    </Phone>
  );
}

// ─────────────────────────────────────────────────
// 2. Meet Maya
// ─────────────────────────────────────────────────
function QHMeet() {
  const a11y = useA11y();
  const QH = liftContrast(getQH(useMode()), a11y);
  const HAND = fH(a11y), SERIF = fS(a11y);
  const isMorning = QH.name === 'morning';
  return (
    <Phone theme={makeTheme(QH)} statusDark={QH.statusDark}>
      <div style={{ paddingTop: 50, height: '100%', position: 'relative', overflow: 'hidden',
        background: QH.pageGrad }}>
        <LampGlow top={70} size={360} color={QH.glowRGBA}/>

        <div style={{ padding: '18px 28px 0', position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ fontFamily: FONT, fontSize: 11, letterSpacing: 2, color: QH.muted, textTransform: 'uppercase' }}>
              Step 3 of 4
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              {[1,1,1,0].map((on, i) => (
                <div key={i} style={{ width: 18, height: 3, borderRadius: 2, background: on ? QH.accent : QH.dim }}/>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 28 }}>
            <div style={{ position: 'relative' }}>
              <MayaAvatar size={140}
                skin={isMorning ? '#C99A87' : '#B58A78'}
                cloth={isMorning ? '#5E4856' : '#332A3C'}
                bg={isMorning ? '#D9CFC2' : '#3A3247'}
                hair={isMorning ? '#2A1F1A' : '#181216'}
                ring={isMorning ? 'rgba(200,120,107,0.42)' : 'rgba(232,168,156,0.38)'}/>
              <div style={{ position: 'absolute', bottom: -2, right: -8,
                background: QH.statusPillBg, borderRadius: 22,
                padding: '6px 11px', display: 'flex', gap: 2.5, alignItems: 'center',
                border: `1px solid ${QH.border}`,
                boxShadow: isMorning ? '0 4px 12px rgba(43,31,20,0.10)' : '0 4px 12px rgba(0,0,0,0.4)' }}>
                <div style={{ width: 6, height: 6, borderRadius: 3, background: QH.sage, marginRight: 4 }}/>
                <span style={{ color: QH.textSoft, fontSize: 9, fontWeight: 600, letterSpacing: 0.8, marginRight: 4, fontFamily: FONT }}>HERE NOW</span>
                {[3,5,7,4,6].map((h, i) => (
                  <div key={i} style={{ width: 2, height: h, background: QH.accent, borderRadius: 1 }}/>
                ))}
              </div>
            </div>
          </div>

          <div style={{ textAlign: 'center', marginTop: 26 }}>
            <div style={{ fontFamily: HAND, fontSize: 22, color: QH.blush, marginBottom: 4 }}>
              hi, I&rsquo;m
            </div>
            <div style={{ fontFamily: SERIF, fontSize: 38, lineHeight: 1.0, color: QH.text, letterSpacing: -0.8 }}>
              Maya.
            </div>
            <div style={{ fontFamily: FONT, fontSize: 12, color: QH.muted, marginTop: 8, letterSpacing: 0.4 }}>
              {HAVEN_DATA.therapist.credentials} &middot; {HAVEN_DATA.therapist.practice.split(' \u00B7 ')[0]}
            </div>
          </div>

          <div style={{ marginTop: 26, padding: '22px 22px', background: QH.surface, borderRadius: 20,
            border: `1px solid ${QH.borderSoft}`, position: 'relative' }}>
            <div style={{ position: 'absolute', top: -1, left: 28, right: 28, height: 1,
              background: QH.thinDivider }}/>
            <div style={{ fontFamily: SERIF, fontSize: 19, lineHeight: 1.45, color: QH.text, fontStyle: 'italic' }}>
              &ldquo;Healing happens between sessions, not in them. The work is in the small, hard moments &mdash; 2am, after a fight, before a meeting.&rdquo;
            </div>
            <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 24, height: 1, background: QH.dim }}/>
              <div style={{ fontFamily: FONT, fontSize: 11, color: QH.muted, letterSpacing: 0.6 }}>
                Maya&rsquo;s practice philosophy
              </div>
            </div>
          </div>

          <div style={{ marginTop: 18, padding: '14px 18px', background: QH.iconChipBg,
            borderRadius: 14, border: `1px solid ${QH.border}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Icon name="sparkle" size={12} style={{ color: QH.accent }}/>
              <span style={{ fontFamily: FONT, fontSize: 11, color: QH.accent, letterSpacing: 1.5, fontWeight: 600 }}>
                HOW THE TWIN WORKS
              </span>
            </div>
            <div style={{ fontFamily: FONT, fontSize: 13, color: QH.textSoft, marginTop: 8, lineHeight: 1.5 }}>
              Trained on 86 hours of Maya&rsquo;s sessions. She reviews how the twin talks to you every week.
            </div>
          </div>
        </div>

        <div style={{ position: 'absolute', bottom: 30, left: 24, right: 24, zIndex: 1 }}>
          <button style={{
            width: '100%', height: 54, borderRadius: 27, border: 'none',
            background: QH.accent, color: QH.accentInk,
            fontFamily: FONT, fontSize: 15, fontWeight: 600,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            boxShadow: QH.btnShadow, cursor: 'pointer',
          }}>
            Say hi to Maya <Icon name="arrow" size={14}/>
          </button>
          <div style={{ textAlign: 'center', marginTop: 12, fontFamily: FONT, fontSize: 11, color: QH.muted }}>
            Or <span style={{ color: QH.accent, textDecoration: 'underline', textDecorationColor: 'rgba(176,118,46,0.4)' }}>browse other therapists</span>
          </div>
        </div>
      </div>
    </Phone>
  );
}

// ─────────────────────────────────────────────────
// 3. Home
// ─────────────────────────────────────────────────
function QHHome() {
  const a11y = useA11y();
  const QH = liftContrast(getQH(useMode()), a11y);
  const HAND = fH(a11y), SERIF = fS(a11y);
  const isMorning = QH.name === 'morning';
  return (
    <Phone theme={makeTheme(QH)} statusDark={QH.statusDark}>
      <div style={{ paddingTop: 50, height: '100%', overflow: 'hidden', position: 'relative',
        background: QH.pageGradSoft }}>
        <LampGlow top={-80} size={320} color={QH.glowRGBASoft}/>

        <div style={{ padding: '14px 24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative', zIndex: 1 }}>
          <div style={{ fontFamily: FONT, fontSize: 11, letterSpacing: 1.6, color: QH.muted, textTransform: 'uppercase' }}>
            Wednesday {QH.partOfDay}
          </div>
          <div style={{ width: 36, height: 36, borderRadius: 18, border: `1px solid ${QH.borderSoft}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
            <MayaAvatar size={32}
              skin={isMorning ? '#C99A87' : '#B58A78'}
              cloth={isMorning ? '#5E4856' : '#332A3C'}
              bg={isMorning ? '#D9CFC2' : '#3A3247'}
              hair={isMorning ? '#2A1F1A' : '#181216'}/>
          </div>
        </div>

        <div style={{ padding: '18px 24px 0', position: 'relative', zIndex: 1 }}>
          <div style={{ fontFamily: HAND, fontSize: 22, color: QH.blush, lineHeight: 1 }}>
            {QH.greetingHand}
          </div>
          <div style={{ fontFamily: SERIF, fontSize: 32, lineHeight: 1.05, color: QH.text, letterSpacing: -0.4, marginTop: 6 }}>
            {QH.greeting}
          </div>
          <div style={{ fontFamily: FONT, fontSize: 13, color: QH.muted, marginTop: 8, lineHeight: 1.45 }}>
            {isMorning ? 'No need to be ready yet. We can ease in.' : 'Take a breath. There\u2019s no rush tonight.'}
          </div>
        </div>

        <div style={{ margin: '18px 24px 0', padding: '14px 18px', borderRadius: 16,
          background: QH.surface, border: `1px solid ${QH.borderSoft}` }}>
          <div style={{ fontFamily: FONT, fontSize: 11, color: QH.muted, letterSpacing: 0.6, marginBottom: 10 }}>
            How&rsquo;s right now?
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 6 }}>
            {['rough', 'low', 'meh', 'okay', 'good', 'lifted'].map((label, i) => (
              <div key={label} style={{ flex: 1, textAlign: 'center', padding: '8px 0',
                borderRadius: 10, border: `1px solid ${i === 3 ? QH.accent : QH.borderSoft}`,
                background: i === 3 ? QH.pillActiveBg : 'transparent',
                fontFamily: FONT, fontSize: 11, color: i === 3 ? QH.accent : QH.muted, fontWeight: i === 3 ? 600 : 400 }}>
                {label}
              </div>
            ))}
          </div>
        </div>

        <div style={{ margin: '12px 24px 0', padding: '18px 20px', background: QH.surface, borderRadius: 18,
          border: `1px solid ${QH.borderSoft}`, position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 6, height: 6, borderRadius: 3, background: QH.accent }}/>
            <div style={{ fontFamily: FONT, fontSize: 10, letterSpacing: 1.4, color: QH.accent, fontWeight: 600 }}>
              SOMETHING YOU SAID TUESDAY
            </div>
          </div>
          <div style={{ fontFamily: SERIF, fontSize: 19, lineHeight: 1.35, color: QH.text, marginTop: 10, fontStyle: 'italic' }}>
            &ldquo;The worst part isn&rsquo;t failing &mdash; it&rsquo;s being seen failing.&rdquo;
          </div>
          <div style={{ marginTop: 12, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {HAVEN_DATA.lastSession.themes.map((t) => (
              <span key={t} style={{ fontSize: 11, color: QH.textSoft, padding: '4px 10px',
                borderRadius: 11, border: `1px solid ${QH.borderSoft}`,
                background: isMorning ? 'rgba(43,31,20,0.04)' : 'rgba(246,236,217,0.04)' }}>
                {t}
              </span>
            ))}
          </div>
        </div>

        <div style={{ margin: '12px 24px 0', padding: '18px 20px', borderRadius: 18,
          background: QH.cardSoftGrad, border: `1px solid ${QH.border}`, position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
              <Icon name="sparkle" size={11} style={{ color: QH.accent }}/>
              <span style={{ fontFamily: FONT, fontSize: 10, letterSpacing: 1.4, color: QH.accent, fontWeight: 600 }}>
                {QH.homePromptLabel}
              </span>
            </div>
            <div style={{ fontFamily: FONT, fontSize: 10, color: QH.dim }}>{QH.noteTime}</div>
          </div>
          <div style={{ fontFamily: SERIF, fontSize: 17, lineHeight: 1.4, color: QH.text, marginTop: 10 }}>
            {isMorning
              ? 'You said the chest tightness shows up before meetings. Want to take three minutes before yours at 10?'
              : 'Last Tuesday you noticed the chest tightness shows up before meetings. Want to breathe together before yours at 10?'}
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <button style={{ flex: 1, height: 40, borderRadius: 20, border: 'none', background: QH.accent, color: QH.accentInk,
              fontFamily: FONT, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
              Yes, let&rsquo;s
            </button>
            <button style={{ height: 40, padding: '0 16px', borderRadius: 20, border: `1px solid ${QH.borderSoft}`,
              background: 'transparent', color: QH.textSoft, fontFamily: FONT, fontSize: 13, cursor: 'pointer' }}>
              Maybe later
            </button>
          </div>
        </div>

        <TabBar active="home" items={TAB_ITEMS} theme={makeTheme(QH)}/>
      </div>
    </Phone>
  );
}

// ─────────────────────────────────────────────────
// 4. Chat
// ─────────────────────────────────────────────────
function QHChat() {
  const a11y = useA11y();
  const QH = liftContrast(getQH(useMode()), a11y);
  const HAND = fH(a11y), SERIF = fS(a11y);
  const isMorning = QH.name === 'morning';
  return (
    <Phone theme={makeTheme(QH)} statusDark={QH.statusDark}>
      <div style={{ paddingTop: 50, height: '100%', position: 'relative', overflow: 'hidden',
        background: QH.chatGrad }}>

        <div style={{ padding: '12px 22px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <MayaAvatar size={32}
              skin={isMorning ? '#C99A87' : '#B58A78'}
              cloth={isMorning ? '#5E4856' : '#332A3C'}
              bg={isMorning ? '#D9CFC2' : '#3A3247'}
              hair={isMorning ? '#2A1F1A' : '#181216'}/>
            <div>
              <div style={{ fontFamily: SERIF, fontSize: 15, color: QH.text, fontStyle: 'italic' }}>{QH.chatTitle}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 2 }}>
                <div style={{ width: 5, height: 5, borderRadius: 3, background: QH.sage }}/>
                <span style={{ fontFamily: FONT, fontSize: 10, color: QH.muted, letterSpacing: 0.4 }}>
                  {QH.chatStatus}
                </span>
              </div>
            </div>
          </div>
          <Icon name="close" size={18} style={{ color: QH.muted }}/>
        </div>

        <div style={{ padding: '24px 22px 0', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {HAVEN_DATA.conversation2am.map((m, i) => {
            const isUser = m.from === 'user';
            return (
              <div key={i} style={{ alignSelf: isUser ? 'flex-end' : 'flex-start', maxWidth: '84%' }}>
                {!isUser && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                    <div style={{ width: 4, height: 4, borderRadius: 2, background: QH.accent }}/>
                    <span style={{ fontFamily: FONT, fontSize: 9, letterSpacing: 1.2, color: QH.dim }}>{m.t} AM</span>
                  </div>
                )}
                <div style={{
                  fontFamily: isUser ? FONT : SERIF,
                  fontSize: isUser ? 14 : 16, lineHeight: 1.5,
                  color: QH.text,
                  padding: isUser ? '11px 15px' : '0',
                  background: isUser ? QH.surface : 'transparent',
                  borderRadius: isUser ? 18 : 0,
                  border: isUser ? `1px solid ${QH.borderSoft}` : 'none',
                }}>
                  {m.text}
                </div>
              </div>
            );
          })}

          <div style={{ marginTop: 4, padding: '16px 18px', borderRadius: 18,
            background: QH.cardGoldGrad, border: `1px solid ${QH.border}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Icon name={isMorning ? 'leaf' : 'moon'} size={13} style={{ color: QH.accent }}/>
              <span style={{ fontFamily: FONT, fontSize: 10, letterSpacing: 1.4, color: QH.accent, fontWeight: 600 }}>
                {QH.windDownLabel}
              </span>
            </div>
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
              {HAVEN_DATA.windDown.steps.map((s, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                  <div style={{ width: 20, height: 20, borderRadius: 10, border: `1px solid ${QH.accent}`,
                    color: QH.accent, fontSize: 9, fontFamily: FONT, fontWeight: 600,
                    display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {i + 1}
                  </div>
                  <div style={{ flex: 1, fontFamily: FONT, fontSize: 13, color: QH.text }}>{s.t}</div>
                  <div style={{ fontFamily: FONT, fontSize: 11, color: QH.dim }}>{s.minutes} min</div>
                </div>
              ))}
            </div>
            <button style={{ width: '100%', marginTop: 14, height: 42, borderRadius: 21, border: 'none',
              background: QH.accent, color: QH.accentInk, fontFamily: FONT, fontSize: 13, fontWeight: 600,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, cursor: 'pointer' }}>
              <Icon name="play" size={12}/> Begin &middot; in Maya&rsquo;s voice
            </button>
          </div>
        </div>

        <div style={{ position: 'absolute', bottom: 26, left: 16, right: 16,
          background: QH.surface, border: `1px solid ${QH.borderSoft}`, borderRadius: 24,
          padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10,
          boxShadow: QH.composerShadow }}>
          <Icon name="mic" size={18} style={{ color: QH.muted }}/>
          <span style={{ flex: 1, fontFamily: FONT, fontSize: 13, color: QH.dim }}>Type, or hold to speak&hellip;</span>
          <div style={{ width: 34, height: 34, borderRadius: 17, background: QH.iconChipBgHi,
            color: QH.accent, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="waveform" size={14}/>
          </div>
        </div>
      </div>
    </Phone>
  );
}

// ─────────────────────────────────────────────────
// 5. Journal
// ─────────────────────────────────────────────────
function QHJournal() {
  const a11y = useA11y();
  const QH = liftContrast(getQH(useMode()), a11y);
  const HAND = fH(a11y), SERIF = fS(a11y);
  const isMorning = QH.name === 'morning';
  return (
    <Phone theme={makeTheme(QH)} statusDark={QH.statusDark}>
      <div style={{ paddingTop: 50, height: '100%', overflow: 'hidden', position: 'relative',
        background: QH.pageGradSoft }}>
        <LampGlow top={-60} size={300} color={QH.glowRGBASoft}/>

        <div style={{ padding: '16px 24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative', zIndex: 1 }}>
          <div style={{ fontFamily: FONT, fontSize: 11, letterSpacing: 1.6, color: QH.muted, textTransform: 'uppercase' }}>
            Journal &middot; 14 entries
          </div>
          <div style={{ width: 32, height: 32, borderRadius: 16, background: QH.iconChipBg,
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: QH.accent }}>
            <Icon name="plus" size={16}/>
          </div>
        </div>
        <div style={{ padding: '16px 24px 0', position: 'relative', zIndex: 1 }}>
          <div style={{ fontFamily: HAND, fontSize: 20, color: QH.blush }}>{QH.journalLabel}</div>
          <div style={{ fontFamily: SERIF, fontSize: 30, color: QH.text, letterSpacing: -0.3, marginTop: 4 }}>
            Three sentences is enough.
          </div>
        </div>

        <div style={{ margin: '20px 24px 0', padding: '24px 22px', borderRadius: 22,
          background: QH.cardSoftGrad,
          border: `1px solid ${QH.border}`, position: 'relative', zIndex: 1 }}>
          <div style={{ position: 'absolute', top: 16, right: 16, display: 'flex', gap: 4 }}>
            {[1,2,3,4].map((i) => (
              <div key={i} style={{ width: 4, height: 4, borderRadius: 2, background: i === 1 ? QH.accent : QH.dim }}/>
            ))}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
            <div style={{ width: 24, height: 24, borderRadius: 12, overflow: 'hidden' }}>
              <MayaAvatar size={24}
                skin={isMorning ? '#C99A87' : '#B58A78'}
                cloth={isMorning ? '#5E4856' : '#332A3C'}
                bg={isMorning ? '#D9CFC2' : '#3A3247'}
                hair={isMorning ? '#2A1F1A' : '#181216'}/>
            </div>
            <span style={{ fontFamily: FONT, fontSize: 11, color: QH.accent, letterSpacing: 1.2, fontWeight: 600 }}>
              MAYA SUGGESTS
            </span>
          </div>
          <div style={{ fontFamily: SERIF, fontSize: 23, lineHeight: 1.3, color: QH.text, marginTop: 12, fontStyle: 'italic' }}>
            {isMorning ? 'What does this morning need from you?' : 'What did your body know before your mind caught up?'}
          </div>
          <div style={{ marginTop: 14, fontFamily: FONT, fontSize: 12, color: QH.muted, lineHeight: 1.5 }}>
            No one will see this unless you share it. Even a sentence counts.
          </div>
          <button style={{ marginTop: 16, height: 40, padding: '0 20px', borderRadius: 20, border: 'none',
            background: QH.accent, color: QH.accentInk, fontFamily: FONT, fontSize: 13, fontWeight: 600,
            display: 'inline-flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
            <Icon name="pencil" size={13}/> Begin writing
          </button>
        </div>

        <div style={{ margin: '24px 24px 0', position: 'relative', zIndex: 1 }}>
          <div style={{ fontFamily: FONT, fontSize: 10, color: QH.muted, letterSpacing: 1.4, fontWeight: 600 }}>
            RECENT
          </div>
          {[
            { d: 'Last night', t: 'I think I was angrier at him than I admitted...', shared: true },
            { d: 'Sun \u00B7 11:14 PM', t: 'Mom called. I let it go to voicemail and didn\u2019t feel guilty for once.' },
            { d: 'Fri \u00B7 late', t: 'The review went better than I thought.' },
          ].map((e, i) => (
            <div key={i} style={{ marginTop: 14, paddingBottom: 14, borderBottom: i < 2 ? `1px solid ${QH.borderSoft}` : 'none' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ fontFamily: FONT, fontSize: 10, color: QH.dim, letterSpacing: 1 }}>{e.d.toUpperCase()}</div>
                {e.shared && <span style={{ fontSize: 9, color: QH.accent, letterSpacing: 1, fontFamily: FONT, fontWeight: 600 }}>SHARED</span>}
              </div>
              <div style={{ fontFamily: SERIF, fontSize: 15, color: QH.textSoft, marginTop: 6, lineHeight: 1.4, fontStyle: 'italic' }}>
                &ldquo;{e.t}&rdquo;
              </div>
            </div>
          ))}
        </div>

        <TabBar active="journal" items={TAB_ITEMS} theme={makeTheme(QH)}/>
      </div>
    </Phone>
  );
}

// ─────────────────────────────────────────────────
// 6. Progress
// ─────────────────────────────────────────────────
function QHProgress() {
  const a11y = useA11y();
  const QH = liftContrast(getQH(useMode()), a11y);
  const HAND = fH(a11y), SERIF = fS(a11y);
  const id = React.useId();
  return (
    <Phone theme={makeTheme(QH)} statusDark={QH.statusDark}>
      <div style={{ paddingTop: 50, height: '100%', overflow: 'auto', position: 'relative',
        background: QH.pageGradSoft }}>
        <div style={{ padding: '16px 24px 0' }}>
          <div style={{ fontFamily: FONT, fontSize: 11, letterSpacing: 1.6, color: QH.muted, textTransform: 'uppercase' }}>
            6 weeks with Maya
          </div>
          <div style={{ fontFamily: HAND, fontSize: 22, color: QH.blush, marginTop: 8 }}>
            look how far you&rsquo;ve come
          </div>
          <div style={{ fontFamily: SERIF, fontSize: 30, color: QH.text, letterSpacing: -0.3, marginTop: 2 }}>
            What you&rsquo;ve learned
          </div>
        </div>

        <div style={{ margin: '20px 24px 0', padding: '20px 22px', borderRadius: 20,
          background: QH.surface, border: `1px solid ${QH.borderSoft}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icon name="sparkle" size={13} style={{ color: QH.accent }}/>
            <span style={{ fontFamily: FONT, fontSize: 10, letterSpacing: 1.4, color: QH.accent, fontWeight: 600 }}>
              SOMETHING TO HOLD ONTO
            </span>
          </div>
          <div style={{ fontFamily: SERIF, fontSize: 19, lineHeight: 1.35, color: QH.text, marginTop: 10 }}>
            Your spirals are getting <em style={{ color: QH.accent, fontStyle: 'italic' }}>shorter</em>. Six weeks ago they lasted three days. This month, the longest was six hours.
          </div>
          <div style={{ marginTop: 14, fontFamily: FONT, fontSize: 11, color: QH.muted, letterSpacing: 0.3 }}>
            Drawn from your check-ins and journal entries.
          </div>
        </div>

        <div style={{ margin: '14px 24px 0', padding: '18px 22px', borderRadius: 20, background: QH.surface, border: `1px solid ${QH.borderSoft}` }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div style={{ fontFamily: FONT, fontSize: 12, color: QH.muted, letterSpacing: 0.4 }}>This week</div>
            <div style={{ fontFamily: SERIF, fontSize: 16, color: QH.text, fontStyle: 'italic' }}>steadier than last</div>
          </div>
          <svg viewBox="0 0 280 80" style={{ width: '100%', marginTop: 14, display: 'block' }}>
            <defs>
              <linearGradient id={`grad-${id}`} x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor={QH.accent} stopOpacity="0.4"/>
                <stop offset="100%" stopColor={QH.accent} stopOpacity="0"/>
              </linearGradient>
            </defs>
            {(() => {
              const w = HAVEN_DATA.moodWeek;
              const pts = w.map((d, i) => `${10 + i * 43},${80 - d.score * 9}`).join(' ');
              const fillPts = `10,80 ${pts} 268,80`;
              return (
                <>
                  <polyline points={fillPts} fill={`url(#grad-${id})`} stroke="none"/>
                  <polyline points={pts} fill="none" stroke={QH.accent} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                  {w.map((d, i) => (
                    <circle key={i} cx={10 + i * 43} cy={80 - d.score * 9} r="2.8" fill={QH.accent}/>
                  ))}
                </>
              );
            })()}
          </svg>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, padding: '0 6px' }}>
            {HAVEN_DATA.moodWeek.map((d) => (
              <div key={d.day} style={{ fontFamily: FONT, fontSize: 9, color: QH.dim, letterSpacing: 0.5 }}>{d.day}</div>
            ))}
          </div>
        </div>

        <div style={{ margin: '14px 24px 100px' }}>
          <div style={{ fontFamily: FONT, fontSize: 10, color: QH.muted, letterSpacing: 1.4, fontWeight: 600, marginBottom: 10 }}>
            WHAT KEEPS COMING UP
          </div>
          {HAVEN_DATA.themes.map((t) => (
            <div key={t.label} style={{ padding: '14px 0', borderBottom: `1px solid ${QH.borderSoft}`,
              display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: SERIF, fontSize: 17, color: QH.text }}>{t.label}</div>
                <div style={{ fontFamily: FONT, fontSize: 11, color: QH.muted, marginTop: 2 }}>{t.note}</div>
              </div>
              <div style={{ fontFamily: FONT, fontSize: 11, color: t.trend === 'down' ? QH.sage : t.trend === 'new' ? QH.accent : QH.muted, letterSpacing: 0.5 }}>
                {t.trend === 'down' ? '↓ easing' : t.trend === 'new' ? '· new' : '— flat'}
              </div>
            </div>
          ))}
        </div>

        <TabBar active="progress" items={TAB_ITEMS} theme={makeTheme(QH)}/>
      </div>
    </Phone>
  );
}

Object.assign(window, { QHWelcome, QHMeet, QHHome, QHChat, QHJournal, QHProgress });
