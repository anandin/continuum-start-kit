// Shared content across all three directions — keeps copywriting consistent
// so the variations are about visual/interaction language, not different stories.

const therapist = {
  name: 'Dr. Maya Okafor',
  short: 'Dr. Maya',
  initials: 'MO',
  credentials: 'PhD, LCSW · Trauma-informed CBT',
  practice: '11 years · Brooklyn, NY',
  philosophy:
    "I think healing happens between sessions, not in them. The work is in the small, hard moments — 2am, after a fight, before a meeting. That's where the twin shows up.",
  trained: 'Trained on 86 hours of Maya\'s sessions and case notes.',
};

// Reusable conversation for the 2am hero moment.
// User is anxious about a work review tomorrow. Goal: heard → grounded → asleep.
const conversation2am = [
  { from: 'twin', text: "You're up. What's keeping you?", t: '2:14' },
  { from: 'user', text: "Performance review tomorrow. I keep replaying the meeting last week where I went blank.", t: '2:14' },
  { from: 'twin', text: "Going blank in front of people you respect — that's a specific kind of awful. You haven't slept since.", t: '2:15' },
  { from: 'user', text: "Yeah. And I can already hear my brain making it bigger than it is.", t: '2:16' },
  { from: 'twin', text: "Hear it, but don't argue with it tonight. Maya has a thing she says — \"sleep is the work, the rest is rehearsal.\" You don't need to solve this at 2am. Want to try the wind-down we built last month?", t: '2:17' },
];

// What the wind-down ritual contains
const windDown = {
  title: 'Tonight\'s wind-down',
  steps: [
    { t: 'Box breath', d: '4 in · 4 hold · 4 out · 4 hold', minutes: 2 },
    { t: 'Body scan', d: 'Maya\'s voice, slow', minutes: 6 },
    { t: 'Tomorrow note', d: 'One line for morning-you', minutes: 1 },
  ],
  totalMin: 9,
};

// Last session continuity — surfaces "we talked about X last Tuesday"
const lastSession = {
  weekday: 'Tuesday',
  date: 'Nov 12',
  themes: ['perfectionism at work', 'not asking for help'],
  insight: 'You said the worst part isn\'t failing — it\'s being seen failing.',
  homework: 'Tell one person about something you\'re struggling with this week.',
};

// Today's nudge from the twin
const todayNudge = {
  body: 'Last Tuesday you noticed the chest tightness shows up before meetings. What if we breathed before yours at 10?',
  generatedAt: '6:42 AM',
};

// Mood / progress
const moodWeek = [
  { day: 'Mon', score: 4, note: 'tense' },
  { day: 'Tue', score: 6, note: 'session' },
  { day: 'Wed', score: 5, note: 'ok' },
  { day: 'Thu', score: 3, note: 'spiral' },
  { day: 'Fri', score: 4, note: 'recovered' },
  { day: 'Sat', score: 7, note: 'rest' },
  { day: 'Sun', score: 6, note: 'ready' },
];

// Themes the twin has noticed (continuity differentiator)
const themes = [
  { label: 'Self-criticism', count: 14, trend: 'down', note: 'Less harsh this month' },
  { label: 'Sleep', count: 9, trend: 'flat', note: 'Stable around 6.5h' },
  { label: 'Boundaries with mom', count: 7, trend: 'new', note: 'Came up 3 times this week' },
];

// Journal prompts
const journalPrompts = [
  "What's the version of today you're afraid to write down?",
  "What did your body know before your mind caught up?",
  "Who would you tell if you weren't worried about how it sounded?",
  "What's a kindness you've withheld from yourself this week?",
];

// Goals (commitments — Haven calls them "commitments")
const goals = [
  { id: 'g1', title: 'Tell one person what I\'m struggling with', done: true, due: 'this week' },
  { id: 'g2', title: 'Notice the spiral, name it, breathe twice', done: false, due: 'daily' },
  { id: 'g3', title: 'Sleep before midnight on weeknights', done: false, due: 'M–F' },
];

Object.assign(window, {
  HAVEN_DATA: {
    therapist,
    conversation2am,
    windDown,
    lastSession,
    todayNudge,
    moodWeek,
    themes,
    journalPrompts,
    goals,
  },
});
