// Shared phone-frame + small primitives used across all three directions.
// Frame is intentionally minimal — each direction owns its content.

function Phone({ children, theme = {}, statusDark = false, label }) {
  const W = 360;
  const H = 740;
  return (
    <div style={{
      width: W, height: H, position: 'relative',
      background: theme.bg || '#fff',
      color: theme.text || '#000',
      overflow: 'hidden',
      fontFamily: theme.font || 'Geist, -apple-system, system-ui, sans-serif',
    }}>
      {/* status bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 38,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '14px 22px 0', zIndex: 100,
        fontSize: 13, fontWeight: 600, letterSpacing: -0.1,
        color: statusDark ? '#fff' : '#000',
        opacity: 0.9, fontFamily: '-apple-system, "SF Pro", system-ui, sans-serif',
      }}>
        <span>9:41</span>
        <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
          <svg width="16" height="10" viewBox="0 0 16 10"><path d="M0 8h2v2H0zM4 6h2v4H4zM8 4h2v6H8zM12 1h2v9h-2z" fill="currentColor"/></svg>
          <svg width="14" height="10" viewBox="0 0 14 10"><path d="M7 3a6 6 0 014.2 1.7l1.1-1.2A8 8 0 007 1a8 8 0 00-5.3 2.5l1.1 1.2A6 6 0 017 3z" fill="currentColor"/><circle cx="7" cy="8" r="1.4" fill="currentColor"/></svg>
          <svg width="22" height="10" viewBox="0 0 22 10"><rect x="0.5" y="0.5" width="18" height="9" rx="2" stroke="currentColor" fill="none" opacity="0.5"/><rect x="2" y="2" width="14" height="6" rx="1" fill="currentColor"/></svg>
        </div>
      </div>
      {children}
      {/* home indicator */}
      <div style={{
        position: 'absolute', bottom: 6, left: '50%', transform: 'translateX(-50%)',
        width: 110, height: 4, borderRadius: 2,
        background: statusDark ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.3)',
        zIndex: 100,
      }} />
    </div>
  );
}

// Tiny SVG icon set — single stroke, currentColor.
const Icon = ({ name, size = 18, ...rest }) => {
  const s = size;
  const paths = {
    home: <path d="M3 10l9-7 9 7v10a1 1 0 01-1 1h-5v-7h-6v7H4a1 1 0 01-1-1V10z"/>,
    chat: <path d="M21 12a8 8 0 01-11.5 7.2L3 21l1.8-6.5A8 8 0 1121 12z"/>,
    book: <path d="M4 4h11a3 3 0 013 3v13H7a3 3 0 01-3-3V4z M4 4v13a3 3 0 003 3h11"/>,
    chart: <path d="M3 21V3 M3 21h18 M7 14l4-4 4 4 5-7"/>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/></>,
    plus: <path d="M12 5v14M5 12h14"/>,
    send: <path d="M22 2L11 13 M22 2l-7 20-4-9-9-4 20-7z"/>,
    mic: <><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0 M12 18v3"/></>,
    moon: <path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"/>,
    leaf: <path d="M5 21c0-9 7-16 16-16-1 9-7 16-16 16z M5 21l8-8"/>,
    heart: <path d="M21 8.5a5.5 5.5 0 00-9-4.2A5.5 5.5 0 003 8.5c0 6 9 11 9 11s9-5 9-11z"/>,
    arrow: <path d="M5 12h14 M13 6l6 6-6 6"/>,
    check: <path d="M4 12l5 5L20 6"/>,
    play: <path d="M6 4l14 8-14 8z"/>,
    pause: <path d="M6 4h4v16H6z M14 4h4v16h-4z"/>,
    close: <path d="M6 6l12 12 M18 6L6 18"/>,
    sparkle: <path d="M12 3l1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3z M19 3l.7 2L22 6l-2.3.5L19 9l-.7-2.5L16 6l2.3-1L19 3z"/>,
    quote: <path d="M7 7h4v8H5v-3a5 5 0 012-5z M16 7h4v8h-6v-3a5 5 0 012-5z"/>,
    pencil: <path d="M3 21l4-1 11-11-3-3L4 17l-1 4z M14 6l3 3"/>,
    phone: <path d="M5 4h4l2 5-3 2a12 12 0 005 5l2-3 5 2v4a2 2 0 01-2 2A17 17 0 013 6a2 2 0 012-2z"/>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18 M8 3v4 M16 3v4"/></>,
    waveform: <path d="M3 12h2 M7 8v8 M11 5v14 M15 8v8 M19 11v2 M21 12h-2"/>,
    target: <><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/></>,
    bookmark: <path d="M6 3h12v18l-6-4-6 4V3z"/>,
    chevR: <path d="M9 6l6 6-6 6"/>,
    chevD: <path d="M6 9l6 6 6-6"/>,
  };
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"
      {...rest}>
      {paths[name]}
    </svg>
  );
};

// Therapist avatar — drawn as SVG portrait silhouette so we don't need real photos.
// Each direction gets its own treatment by passing different colors.
function MayaAvatar({ size = 48, skin = '#C9956E', cloth = '#3A2E26', bg = '#EFE4D2', hair = '#1F1A15', ring }) {
  const id = React.useId();
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" style={{ display: 'block' }}>
      <defs>
        <clipPath id={`c${id}`}><circle cx="32" cy="32" r="32"/></clipPath>
      </defs>
      <g clipPath={`url(#c${id})`}>
        <rect width="64" height="64" fill={bg}/>
        {/* hair back */}
        <path d="M10 34 Q12 16 32 14 Q52 16 54 34 L54 50 L10 50 Z" fill={hair}/>
        {/* face */}
        <ellipse cx="32" cy="34" rx="14" ry="17" fill={skin}/>
        {/* hair front sweep */}
        <path d="M16 28 Q22 14 32 14 Q42 14 48 28 Q42 22 32 22 Q24 22 16 28 Z" fill={hair}/>
        {/* shoulders / clothing */}
        <path d="M4 64 Q4 50 18 47 Q26 52 32 52 Q38 52 46 47 Q60 50 60 64 Z" fill={cloth}/>
        {/* subtle eyes */}
        <ellipse cx="26.5" cy="34" rx="1" ry="1.4" fill="#1a120a" opacity="0.6"/>
        <ellipse cx="37.5" cy="34" rx="1" ry="1.4" fill="#1a120a" opacity="0.6"/>
        {/* mouth hint */}
        <path d="M28 42 Q32 44 36 42" stroke="#5a3a28" strokeWidth="0.9" fill="none" strokeLinecap="round" opacity="0.55"/>
      </g>
      {ring && <circle cx="32" cy="32" r="31" fill="none" stroke={ring} strokeWidth="1.5"/>}
    </svg>
  );
}

// Tab bar shared shape — directions theme it
function TabBar({ active = 'home', items, theme }) {
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      height: 78, paddingBottom: 18, paddingTop: 6,
      display: 'flex', alignItems: 'center', justifyContent: 'space-around',
      background: theme.tabBg || theme.bg,
      borderTop: theme.tabBorder || `1px solid ${theme.border}`,
      backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)',
      zIndex: 50,
    }}>
      {items.map((item) => {
        const isActive = active === item.key;
        return (
          <div key={item.key} style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            color: isActive ? (theme.tabActive || theme.accent) : (theme.muted || '#888'),
          }}>
            <Icon name={item.icon} size={20} strokeWidth={isActive ? 2 : 1.6}/>
            <span style={{ fontSize: 10, fontWeight: isActive ? 600 : 500, letterSpacing: -0.1 }}>
              {item.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}

const TAB_ITEMS = [
  { key: 'home', icon: 'home', label: 'Today' },
  { key: 'chat', icon: 'chat', label: 'Twin' },
  { key: 'journal', icon: 'book', label: 'Journal' },
  { key: 'progress', icon: 'chart', label: 'Progress' },
  { key: 'profile', icon: 'user', label: 'You' },
];

// Mode (night | morning) — consumed by direction components for palette swap
const ModeCtx = React.createContext('night');
const useMode = () => React.useContext(ModeCtx);
// A11y — when true: swap Caveat→Geist, demote italic serif body→Geist, bump labels to 12px+
const A11yCtx = React.createContext(false);
const useA11y = () => React.useContext(A11yCtx);

function ModeToggle({ mode, setMode, a11y, setA11y }) {
  const opts = [
    { v: 'night', label: 'Night', icon: 'moon' },
    { v: 'morning', label: 'Morning', icon: 'sparkle' },
  ];
  const isNight = mode === 'night';
  const bg = isNight ? 'rgba(20,16,13,0.85)' : 'rgba(255,250,240,0.92)';
  const border = isNight ? 'rgba(240,197,138,0.22)' : 'rgba(43,31,20,0.12)';
  const fg = isNight ? '#F6ECD9' : '#2B1F14';
  const muted = isNight ? '#A09083' : '#847566';
  const accent = isNight ? '#F0C58A' : '#B0762E';
  return (
    <div style={{
      position: 'fixed', top: 16, left: '50%', transform: 'translateX(-50%)',
      zIndex: 200, background: bg,
      backdropFilter: 'blur(20px) saturate(160%)',
      WebkitBackdropFilter: 'blur(20px) saturate(160%)',
      border: `1px solid ${border}`, borderRadius: 999,
      padding: 4, display: 'flex', gap: 2,
      boxShadow: isNight ? '0 8px 24px rgba(0,0,0,0.4)' : '0 8px 24px rgba(43,31,20,0.10)',
      fontFamily: '"Geist", -apple-system, system-ui, sans-serif',
    }}>
      {opts.map((o) => {
        const active = mode === o.v;
        return (
          <button key={o.v} onClick={() => setMode(o.v)} style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '8px 16px', border: 'none', cursor: 'pointer',
            background: active ? (isNight ? 'rgba(240,197,138,0.18)' : 'rgba(176,118,46,0.12)') : 'transparent',
            color: active ? accent : muted,
            borderRadius: 999, fontSize: 13, fontWeight: 600, letterSpacing: 0.1,
            transition: 'all 0.18s ease',
          }}>
            <Icon name={o.icon} size={14}/>
            {o.label}
          </button>
        );
      })}
      <div style={{ width: 1, height: 18, background: border, margin: '0 4px' }}/>
      <button onClick={() => setA11y(!a11y)} style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '8px 14px', border: 'none', cursor: 'pointer',
        background: a11y ? (isNight ? 'rgba(159,187,165,0.20)' : 'rgba(111,142,115,0.16)') : 'transparent',
        color: a11y ? (isNight ? '#9FBBA5' : '#6F8E73') : muted,
        borderRadius: 999, fontSize: 13, fontWeight: 600, letterSpacing: 0.1,
        transition: 'all 0.18s ease',
      }} title="Reading mode: bumps small text, swaps handwriting + italic serif for clearer fonts.">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="9"/><path d="M8 9h8 M8 13h6 M8 17h4"/>
        </svg>
        Reading
      </button>
    </div>
  );
}

Object.assign(window, { Phone, Icon, MayaAvatar, TabBar, TAB_ITEMS, ModeCtx, useMode, ModeToggle, A11yCtx, useA11y });
