// ui.jsx — shared atoms used across screens

// Therapist data — same person across all screens for continuity
const DR_CHEN = {
  name: 'Dr. Maya Chen',
  credential: 'LCSW · CBT, IFS',
  years: '12 yrs',
  philosophy: 'I work with people who think their way through everything. We slow it down, name what\'s actually here, and let the body have a say.',
  voice: 'Warm. Direct. A little dry.',
  trained: '180 hrs of session transcripts · reviewed weekly',
  specialty: ['Anxiety', 'Sleep', 'Perfectionism', 'High-functioning burnout'],
  tagline: 'Your therapist, between sessions.',
};

// Avatar — simple stylized portrait built in CSS so no image asset is needed.
function ChenAvatar({ size = 44, ring = false, ringColor }) {
  const t = useTheme().t;
  const r = ring ? 2 : 0;
  return (
    <div style={{
      width: size + r * 2, height: size + r * 2, borderRadius: '50%',
      padding: r, background: ring ? (ringColor || t.primary) : 'transparent',
      flexShrink: 0,
    }}>
      <div style={{
        width: size, height: size, borderRadius: '50%',
        background: `radial-gradient(circle at 35% 30%, #E8C5A0 0%, #C89878 50%, #8B6B45 100%)`,
        position: 'relative', overflow: 'hidden',
      }}>
        {/* face */}
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 40%, #DCB088 0%, #B48867 70%, transparent 90%)' }} />
        {/* hair */}
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '38%', background: 'linear-gradient(180deg, #2A1810 0%, #3A2418 90%, transparent)' }} />
        <div style={{ position: 'absolute', top: '8%', left: '15%', width: '70%', height: '20%', background: '#2A1810', borderRadius: '50% 50% 30% 30%' }} />
        {/* eyes */}
        <div style={{ position: 'absolute', top: '46%', left: '28%', width: '8%', height: '4%', background: '#1f1208', borderRadius: '50%' }} />
        <div style={{ position: 'absolute', top: '46%', right: '28%', width: '8%', height: '4%', background: '#1f1208', borderRadius: '50%' }} />
        {/* mouth */}
        <div style={{ position: 'absolute', top: '64%', left: '38%', width: '24%', height: '2%', background: '#7a3a28', borderRadius: 2, opacity: .7 }} />
      </div>
    </div>
  );
}

function Logo({ size = 22, color }) {
  const t = useTheme().t;
  const c = color || t.primary;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <svg width={size} height={size} viewBox="0 0 24 24">
        <path d="M12 2 L4 6 L4 12 C4 17 7.5 21 12 22 C16.5 21 20 17 20 12 L20 6 Z" fill="none" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/>
        <circle cx="12" cy="13" r="2.5" fill={c}/>
      </svg>
      <span style={{ fontFamily: t.serif, fontSize: size * 0.95, fontWeight: t.headlineWeight, color: c, letterSpacing: '-0.02em' }}>Haven</span>
    </div>
  );
}

// Feather-style icons inline
const Icon = ({ name, size = 18, color = 'currentColor', stroke = 1.75 }) => {
  const props = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (name) {
    case 'home': return <svg {...props}><path d="M3 12L12 4l9 8"/><path d="M5 11v9h14v-9"/></svg>;
    case 'message': return <svg {...props}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
    case 'book': return <svg {...props}><path d="M4 4h11a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4z"/><path d="M4 4v15"/></svg>;
    case 'compass': return <svg {...props}><circle cx="12" cy="12" r="9"/><path d="m15 9-2 6-4 2 2-6z"/></svg>;
    case 'user': return <svg {...props}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
    case 'arrow-right': return <svg {...props}><path d="M5 12h14M13 5l7 7-7 7"/></svg>;
    case 'arrow-up': return <svg {...props}><path d="M12 19V5M5 12l7-7 7 7"/></svg>;
    case 'chevron-right': return <svg {...props}><path d="m9 6 6 6-6 6"/></svg>;
    case 'chevron-left': return <svg {...props}><path d="m15 6-6 6 6 6"/></svg>;
    case 'chevron-down': return <svg {...props}><path d="m6 9 6 6 6-6"/></svg>;
    case 'mic': return <svg {...props}><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>;
    case 'check': return <svg {...props}><path d="m4 12 5 5L20 6"/></svg>;
    case 'plus': return <svg {...props}><path d="M12 5v14M5 12h14"/></svg>;
    case 'moon': return <svg {...props}><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>;
    case 'sun': return <svg {...props}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/></svg>;
    case 'heart': return <svg {...props}><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>;
    case 'leaf': return <svg {...props}><path d="M11 20A7 7 0 0 1 4 13C4 10 4 7 8 4c4 3 4 6 4 9a7 7 0 0 1-1 7Z"/><path d="M8 4v16"/></svg>;
    case 'feather': return <svg {...props}><path d="M20.2 13.5 13 20.7 4 21.5l.7-9 7.2-7.2a5 5 0 1 1 8.3 8.3z"/><path d="M16 8 2 22"/></svg>;
    case 'wave': return <svg {...props}><path d="M2 12c2 0 2-3 5-3s3 6 6 6 3-6 6-6"/></svg>;
    case 'phone': return <svg {...props}><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7 13 13 0 0 0 .7 2.8 2 2 0 0 1-.4 2L8 9.7a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5 13 13 0 0 0 2.8.7 2 2 0 0 1 1.7 2z"/></svg>;
    case 'shield': return <svg {...props}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>;
    case 'sparkle': return <svg {...props}><path d="M12 3v6M12 15v6M3 12h6M15 12h6"/></svg>;
    case 'send': return <svg {...props}><path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/></svg>;
    case 'pause': return <svg {...props}><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>;
    case 'settings': return <svg {...props}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>;
    case 'edit': return <svg {...props}><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 1 1 3 3L12 15l-4 1 1-4z"/></svg>;
    case 'play': return <svg {...props}><path d="m6 4 16 8-16 8z"/></svg>;
    case 'circle': return <svg {...props}><circle cx="12" cy="12" r="9"/></svg>;
    case 'dot': return <svg {...props}><circle cx="12" cy="12" r="3" fill={color}/></svg>;
    case 'target': return <svg {...props}><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill={color}/></svg>;
    case 'trend': return <svg {...props}><path d="m3 17 6-6 4 4 8-8"/><path d="M14 7h7v7"/></svg>;
    case 'bookmark': return <svg {...props}><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>;
    case 'clock': return <svg {...props}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>;
    case 'star': return <svg {...props}><path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z"/></svg>;
    case 'help': return <svg {...props}><circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/></svg>;
    case 'globe': return <svg {...props}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>;
    default: return null;
  }
};

// Bottom tab bar — accepts current screen + setScreen
function TabBar({ current, onChange, theme }) {
  const t = theme;
  const tabs = [
    { id: 'home', icon: 'home', label: 'Today' },
    { id: 'chat', icon: 'message', label: 'Chat' },
    { id: 'journal', icon: 'feather', label: 'Reflect' },
    { id: 'progress', icon: 'compass', label: 'Path' },
  ];
  return (
    <div style={{
      position: 'absolute', left: 12, right: 12, bottom: 14,
      background: 'rgba(255,255,255,0.85)',
      backdropFilter: 'blur(20px) saturate(180%)',
      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      border: `0.5px solid ${t.line}`,
      borderRadius: 28, padding: 8,
      display: 'flex', justifyContent: 'space-around',
      boxShadow: '0 10px 30px -8px rgba(0,0,0,.15)',
    }}>
      {tabs.map(tab => {
        const active = current === tab.id;
        return (
          <button key={tab.id} onClick={() => onChange?.(tab.id)} style={{
            flex: 1, padding: '8px 6px', border: 0, background: active ? t.primarySoft : 'transparent',
            borderRadius: 20, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            color: active ? t.primary : t.inkSoft, cursor: 'pointer', transition: 'all .2s',
            fontFamily: 'inherit',
          }}>
            <Icon name={tab.icon} size={19} color={active ? t.primary : t.inkSoft} stroke={active ? 2 : 1.5}/>
            <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: 0.2 }}>{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}

window.DR_CHEN = DR_CHEN;
window.ChenAvatar = ChenAvatar;
window.Logo = Logo;
window.Icon = Icon;
window.TabBar = TabBar;
