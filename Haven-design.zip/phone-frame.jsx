// phone-frame.jsx — minimal iOS / Android shell. Wraps a 390×844 screen.
// API: <PhoneFrame platform="ios"|"android" dark={bool} time="2:14"><ScreenContent/></PhoneFrame>

function StatusBar({ platform, dark, time }) {
  const c = dark ? '#fff' : '#000';
  const t = useTheme().t;
  if (platform === 'android') {
    return (
      <div style={{ height: 28, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 16px', fontFamily: t.sans, color: c, fontSize: 13, fontWeight: 500, position: 'relative', zIndex: 5 }}>
        <span>{time}</span>
        <div style={{ position: 'absolute', left: '50%', top: 6, transform: 'translateX(-50%)', width: 18, height: 18, borderRadius: '50%', background: '#1a1a1a' }} />
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <svg width="14" height="10" viewBox="0 0 16 12"><path d="M8 11L0 4a11 11 0 0116 0L8 11z" fill={c}/></svg>
          <svg width="13" height="13" viewBox="0 0 16 16"><rect x="3.75" y="2" width="8.5" height="13" rx="1.5" fill={c}/><rect x="5.5" y=".9" width="5" height="2" rx=".5" fill={c}/></svg>
        </div>
      </div>
    );
  }
  // iOS
  return (
    <div style={{ height: 47, display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', padding: '0 28px 12px', position: 'relative', zIndex: 5 }}>
      <span style={{ fontFamily: '-apple-system, "SF Pro", system-ui', fontWeight: 600, fontSize: 16, color: c }}>{time}</span>
      <div style={{ position: 'absolute', left: '50%', top: 11, transform: 'translateX(-50%)', width: 122, height: 35, background: '#000', borderRadius: 24 }} />
      <div style={{ display: 'flex', gap: 6, alignItems: 'center', paddingBottom: 1 }}>
        <svg width="17" height="11" viewBox="0 0 19 12"><rect x="0" y="7.5" width="3" height="4.5" rx=".7" fill={c}/><rect x="4.8" y="5" width="3" height="7" rx=".7" fill={c}/><rect x="9.6" y="2.5" width="3" height="9.5" rx=".7" fill={c}/><rect x="14.4" y="0" width="3" height="12" rx=".7" fill={c}/></svg>
        <svg width="15" height="11" viewBox="0 0 17 12"><path d="M8.5 3.2c2.3 0 4.4.9 5.9 2.4L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5S3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2z" fill={c}/><path d="M8.5 6.8c1.4 0 2.6.5 3.5 1.4l1.1-1.1C11.8 5.9 10.2 5.1 8.5 5.1S5.2 5.9 3.9 7.1L5 8.2c.9-.9 2.1-1.4 3.5-1.4z" fill={c}/><circle cx="8.5" cy="10.5" r="1.5" fill={c}/></svg>
        <svg width="24" height="11" viewBox="0 0 27 13"><rect x=".5" y=".5" width="23" height="12" rx="3.5" stroke={c} strokeOpacity=".4" fill="none"/><rect x="2" y="2" width="19" height="9" rx="2" fill={c}/></svg>
      </div>
    </div>
  );
}

function PhoneFrame({ platform = 'ios', dark = false, time = '9:41', children, label }) {
  const t = useTheme().t;
  const radius = platform === 'ios' ? 56 : 36;
  return (
    <div style={{ width: 390, fontFamily: t.sans }}>
      {label ? <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.2, textTransform: 'uppercase', color: 'rgba(60,50,40,.55)', marginBottom: 8 }}>{label}</div> : null}
      <div style={{
        width: 390, height: 844, borderRadius: radius,
        background: '#0a0a0a',
        padding: 9,
        boxShadow: '0 30px 60px -20px rgba(0,0,0,.35), 0 0 0 .5px rgba(0,0,0,.5)',
        position: 'relative',
      }}>
        <div style={{
          width: '100%', height: '100%', borderRadius: radius - 9,
          overflow: 'hidden', background: dark ? t.night : t.bg,
          display: 'flex', flexDirection: 'column', position: 'relative',
        }}>
          <StatusBar platform={platform} dark={dark} time={time} />
          <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>{children}</div>
          {platform === 'ios' ? (
            <div style={{ height: 34, display: 'flex', alignItems: 'flex-end', justifyContent: 'center', paddingBottom: 8 }}>
              <div style={{ width: 134, height: 5, borderRadius: 3, background: dark ? 'rgba(255,255,255,.4)' : 'rgba(0,0,0,.4)' }} />
            </div>
          ) : (
            <div style={{ height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ width: 110, height: 3, borderRadius: 2, background: dark ? 'rgba(255,255,255,.5)' : 'rgba(0,0,0,.5)' }} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

window.PhoneFrame = PhoneFrame;
