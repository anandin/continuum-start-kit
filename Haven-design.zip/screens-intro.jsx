// screens-intro.jsx — Onboarding, Meet Therapist, Home

// ─── Onboarding ────────────────────────────────────────────────
function ScreenOnboarding() {
  const { t } = useTheme();
  const [step, setStep] = React.useState(0);
  const values = ['Anxious / racing mind', 'Sleep · 2am wakeups', 'Burnout / overwhelm', 'Grief', 'Relationships', 'Just noticing'];
  const [picked, setPicked] = React.useState(['Sleep · 2am wakeups', 'Anxious / racing mind']);
  const togglePick = (v) => setPicked(p => p.includes(v) ? p.filter(x => x !== v) : [...p, v]);

  if (step === 0) {
    return (
      <div style={{ height: '100%', padding: '32px 28px 0', display: 'flex', flexDirection: 'column', background: t.bg }}>
        <div style={{ marginTop: 40 }}><Logo size={26}/></div>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 24 }}>
          <h1 style={{ fontFamily: t.serif, fontSize: 44, fontWeight: t.headlineWeight, color: t.ink, margin: 0, lineHeight: 1.05, letterSpacing: '-0.02em' }}>
            Therapy that<br/>doesn't end<br/><em style={{ color: t.primary, fontStyle: 'italic' }}>at the door.</em>
          </h1>
          <p style={{ fontSize: 16, color: t.inkSoft, lineHeight: 1.5, margin: 0, maxWidth: 320 }}>
            A licensed therapist trains an AI twin in their voice, philosophy, and clinical method. You get them — at 2am, on the train, before the meeting.
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px', background: t.paper, borderRadius: t.radius, border: `1px solid ${t.lineSoft}` }}>
            <Icon name="shield" size={18} color={t.primary}/>
            <span style={{ fontSize: 13, color: t.inkSoft }}>Every reply is reviewed weekly by your therapist</span>
          </div>
        </div>
        <button onClick={() => setStep(1)} style={ctaStyle(t)}>
          <span>Find my therapist</span><Icon name="arrow-right" size={16} color={t.paper}/>
        </button>
        <button style={{ ...ctaStyle(t, true), marginTop: 8 }}>I already have a code</button>
      </div>
    );
  }
  // Step 1 — what brings you
  return (
    <div style={{ height: '100%', padding: '24px 24px 0', display: 'flex', flexDirection: 'column', background: t.bg }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 24 }}>
        <button onClick={() => setStep(0)} style={iconBtnStyle(t)}><Icon name="chevron-left" size={20} color={t.ink}/></button>
        <div style={{ display: 'flex', gap: 4 }}>
          {[0,1,2,3].map(i => <div key={i} style={{ width: 22, height: 3, borderRadius: 2, background: i <= 1 ? t.primary : t.lineSoft }}/>)}
        </div>
        <span style={{ fontFamily: t.mono, fontSize: 11, color: t.inkFaint }}>2/4</span>
      </div>
      <h2 style={{ fontFamily: t.serif, fontSize: 30, fontWeight: t.headlineWeight, color: t.ink, margin: '32px 0 8px', lineHeight: 1.1, letterSpacing: '-0.01em' }}>
        What's bringing you<br/>here, mostly?
      </h2>
      <p style={{ fontSize: 14, color: t.inkSoft, margin: '0 0 20px' }}>Pick what fits. We'll match you to a therapist whose work centers around it.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
        {values.map(v => {
          const on = picked.includes(v);
          return (
            <button key={v} onClick={() => togglePick(v)} style={{
              padding: '14px 16px', border: `1.5px solid ${on ? t.primary : t.line}`,
              background: on ? t.primarySoft : t.paper, borderRadius: t.radius,
              fontFamily: 'inherit', fontSize: 15, color: on ? t.primaryDeep : t.ink,
              fontWeight: 500, textAlign: 'left', cursor: 'pointer', transition: 'all .15s',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            }}>
              <span>{v}</span>
              {on ? <Icon name="check" size={16} color={t.primary} stroke={2.5}/> : null}
            </button>
          );
        })}
      </div>
      <button style={ctaStyle(t)}>Continue<Icon name="arrow-right" size={16} color={t.paper}/></button>
    </div>
  );
}

// ─── Meet your therapist ──────────────────────────────────────
function ScreenMeetTherapist() {
  const { t } = useTheme();
  const [playing, setPlaying] = React.useState(false);
  return (
    <div style={{ height: '100%', overflow: 'auto', background: t.bg, paddingBottom: 90 }}>
      <div style={{ position: 'relative', height: 280, background: `linear-gradient(180deg, ${t.primarySoft} 0%, ${t.bg} 100%)`, overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(circle at 30% 60%, ${t.accentSoft} 0%, transparent 50%)` }}/>
        <div style={{ position: 'absolute', top: 8, left: 16, right: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <button style={iconBtnStyle(t)}><Icon name="chevron-left" size={20} color={t.ink}/></button>
          <span style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.5, color: t.inkSoft, textTransform: 'uppercase' }}>Your match</span>
          <div style={{ width: 36 }}/>
        </div>
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '0 28px 24px', display: 'flex', alignItems: 'flex-end', gap: 16 }}>
          <ChenAvatar size={88} ring ringColor={t.paper}/>
          <div style={{ flex: 1, paddingBottom: 4 }}>
            <h1 style={{ fontFamily: t.serif, fontSize: 26, fontWeight: t.headlineWeight, color: t.ink, margin: 0, letterSpacing: '-0.01em' }}>{DR_CHEN.name}</h1>
            <div style={{ fontSize: 12, color: t.inkSoft, marginTop: 4, fontFamily: t.mono, letterSpacing: 0.5 }}>{DR_CHEN.credential} · {DR_CHEN.years}</div>
          </div>
        </div>
      </div>

      <div style={{ padding: '20px 24px' }}>
        {/* Voice intro */}
        <div onClick={() => setPlaying(p => !p)} style={{
          padding: 18, background: t.paper, border: `1px solid ${t.lineSoft}`, borderRadius: t.radius,
          display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer',
        }}>
          <div style={{ width: 48, height: 48, borderRadius: '50%', background: t.primary, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name={playing ? 'pause' : 'play'} size={20} color={t.paper}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: t.ink }}>Hear Maya, in her own voice</div>
            <div style={{ fontSize: 11, color: t.inkSoft, marginTop: 2 }}>1:42 — what working with me feels like</div>
          </div>
          <Waveform t={t} active={playing}/>
        </div>

        {/* Philosophy */}
        <div style={{ marginTop: 22 }}>
          <Eyebrow t={t}>How I work</Eyebrow>
          <p style={{ fontFamily: t.serif, fontSize: 19, lineHeight: 1.4, color: t.ink, margin: '8px 0 0', fontStyle: 'italic' }}>
            "{DR_CHEN.philosophy}"
          </p>
        </div>

        {/* Specialty chips */}
        <div style={{ marginTop: 22, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {DR_CHEN.specialty.map(s => (
            <span key={s} style={{ fontSize: 12, padding: '6px 11px', background: t.accentSoft, color: t.primaryDeep, borderRadius: 999, fontWeight: 500 }}>{s}</span>
          ))}
        </div>

        {/* Twin trained on */}
        <div style={{ marginTop: 22, padding: 16, background: t.paperWarm, border: `1px solid ${t.lineSoft}`, borderRadius: t.radius }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <Icon name="sparkle" size={18} color={t.accent}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: t.ink }}>Maya's AI twin, between sessions</div>
              <div style={{ fontSize: 12, color: t.inkSoft, lineHeight: 1.5, marginTop: 4 }}>
                Trained on her transcripts, supervised weekly. Never claims to be Maya — claims to be <em>like her</em>. Crisis moments route to a real human in &lt;60s.
              </div>
            </div>
          </div>
        </div>

        <button style={{ ...ctaStyle(t), marginTop: 24 }}>Begin with Maya<Icon name="arrow-right" size={16} color={t.paper}/></button>
        <button style={{ ...ctaStyle(t, true), marginTop: 8 }}>See 2 other matches</button>
      </div>
    </div>
  );
}

function Waveform({ t, active }) {
  const heights = [8, 14, 22, 16, 26, 12, 20, 10, 18, 24, 14, 8];
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
      {heights.map((h, i) => (
        <div key={i} style={{
          width: 2, height: h, background: t.primary,
          borderRadius: 1, opacity: active ? (0.6 + Math.sin((Date.now()/200) + i) * 0.4) : 0.5,
          animation: active ? `bar 1.${i % 5}s ease-in-out infinite alternate` : 'none',
        }}/>
      ))}
    </div>
  );
}

// ─── Home / Today ─────────────────────────────────────────────
function ScreenHome({ onNav }) {
  const { t, tone } = useTheme();
  const today = new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
  return (
    <div style={{ height: '100%', overflow: 'auto', background: t.bg, paddingBottom: 100 }}>
      <div style={{ padding: '20px 24px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.4, textTransform: 'uppercase', color: t.inkFaint }}>{today}</div>
          <h1 style={{ fontFamily: t.serif, fontSize: 28, fontWeight: t.headlineWeight, color: t.ink, margin: '4px 0 0', letterSpacing: '-0.01em' }}>Hi, Sam.</h1>
        </div>
        <button style={{ ...iconBtnStyle(t), width: 40, height: 40 }}><Icon name="user" size={18} color={t.ink}/></button>
      </div>

      <div style={{ padding: '0 24px' }}>
        {/* Continuity card — the differentiator */}
        <div onClick={() => onNav?.('chat')} style={{
          marginTop: 16, padding: 20, background: t.paper, border: `1px solid ${t.lineSoft}`,
          borderRadius: t.radiusLg, cursor: 'pointer', position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', top: 0, left: 0, width: 4, bottom: 0, background: t.primary }}/>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <ChenAvatar size={42}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, fontFamily: t.mono, letterSpacing: 1, color: t.primary, fontWeight: 600 }}>FROM TUESDAY WITH MAYA</div>
              <p style={{ fontFamily: t.serif, fontSize: 17, lineHeight: 1.4, color: t.ink, margin: '6px 0 0', fontStyle: 'italic' }}>
                "When the 2am thing happens — you said it's like the day's not done with you. Want to try the breath thing tonight, before bed?"
              </p>
              <div style={{ marginTop: 14, display: 'flex', gap: 8 }}>
                <button style={{ ...pillBtn(t), background: t.primary, color: t.paper, border: 'none' }}>Yes — set a reminder</button>
                <button style={pillBtn(t)}>Not tonight</button>
              </div>
            </div>
          </div>
        </div>

        {/* Today's check-in row */}
        <div style={{ marginTop: 14, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <button onClick={() => onNav?.('mood')} style={tileStyle(t)}>
            <Icon name="wave" size={18} color={t.accent}/>
            <div style={{ marginTop: 8 }}>
              <div style={{ fontSize: 11, color: t.inkSoft, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase' }}>How's the body?</div>
              <div style={{ fontFamily: t.serif, fontSize: 16, color: t.ink, marginTop: 4 }}>Quick check-in</div>
            </div>
          </button>
          <button onClick={() => onNav?.('journal')} style={tileStyle(t)}>
            <Icon name="feather" size={18} color={t.primary}/>
            <div style={{ marginTop: 8 }}>
              <div style={{ fontSize: 11, color: t.inkSoft, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase' }}>One sentence</div>
              <div style={{ fontFamily: t.serif, fontSize: 16, color: t.ink, marginTop: 4 }}>Reflect</div>
            </div>
          </button>
        </div>

        {/* What Maya's holding */}
        <div style={{ marginTop: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
            <Eyebrow t={t}>What Maya's holding for you</Eyebrow>
            <span style={{ fontSize: 11, color: t.inkFaint }}>3 threads</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { tag: 'Sleep', text: 'The 2am loop — testing earlier wind-downs', day: 'Since Apr 12' },
              { tag: 'Work', text: 'Saying no to the Friday calls', day: 'Since Mar 28' },
              { tag: 'Body', text: 'That clenched-jaw thing in meetings', day: 'Since Mar 14' },
            ].map((thread, i) => (
              <div key={i} style={{
                padding: '12px 14px', background: t.paper, border: `1px solid ${t.lineSoft}`,
                borderRadius: t.radius, display: 'flex', gap: 10, alignItems: 'center',
              }}>
                <div style={{ width: 4, height: 32, background: t.accent, borderRadius: 2 }}/>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <span style={{ fontSize: 10, fontFamily: t.mono, letterSpacing: 1, color: t.accent, textTransform: 'uppercase', fontWeight: 600 }}>{thread.tag}</span>
                    <span style={{ fontSize: 10, color: t.inkFaint }}>· {thread.day}</span>
                  </div>
                  <div style={{ fontSize: 14, color: t.ink, marginTop: 2 }}>{thread.text}</div>
                </div>
                <Icon name="chevron-right" size={16} color={t.inkFaint}/>
              </div>
            ))}
          </div>
        </div>

        {/* Next session */}
        <div style={{ marginTop: 18, padding: 16, background: t.paperWarm, border: `1px solid ${t.lineSoft}`, borderRadius: t.radius, display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: t.primarySoft, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="phone" size={18} color={t.primary}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontFamily: t.mono, color: t.primary, fontWeight: 600, letterSpacing: 0.6 }}>NEXT WITH MAYA</div>
            <div style={{ fontSize: 14, color: t.ink, marginTop: 2 }}>Tuesday · 6:30pm</div>
          </div>
          <button style={pillBtn(t)}>Prep</button>
        </div>
      </div>
    </div>
  );
}

// ─── shared style helpers ─────────────────────────────────────
function ctaStyle(t, ghost = false) {
  return {
    width: '100%', padding: '15px 20px', borderRadius: 999,
    background: ghost ? 'transparent' : t.primary,
    color: ghost ? t.inkSoft : t.paper,
    border: ghost ? `1px solid ${t.line}` : 'none',
    fontFamily: 'inherit', fontSize: 15, fontWeight: 600,
    cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    marginBottom: 14,
  };
}
function iconBtnStyle(t) {
  return {
    width: 36, height: 36, borderRadius: 18, background: t.paper,
    border: `1px solid ${t.lineSoft}`, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  };
}
function pillBtn(t) {
  return {
    padding: '8px 14px', borderRadius: 999, background: t.paper,
    border: `1px solid ${t.line}`, color: t.ink, fontSize: 12, fontWeight: 600,
    cursor: 'pointer', fontFamily: 'inherit',
  };
}
function tileStyle(t) {
  return {
    padding: 14, background: t.paper, border: `1px solid ${t.lineSoft}`,
    borderRadius: t.radius, textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit',
    display: 'flex', flexDirection: 'column', minHeight: 90,
  };
}
function Eyebrow({ t, children }) {
  return <div style={{ fontFamily: t.mono, fontSize: 10, letterSpacing: 1.2, textTransform: 'uppercase', color: t.inkSoft, fontWeight: 600 }}>{children}</div>;
}

window.ScreenOnboarding = ScreenOnboarding;
window.ScreenMeetTherapist = ScreenMeetTherapist;
window.ScreenHome = ScreenHome;
window.havenStyles = { ctaStyle, iconBtnStyle, pillBtn, tileStyle, Eyebrow };
